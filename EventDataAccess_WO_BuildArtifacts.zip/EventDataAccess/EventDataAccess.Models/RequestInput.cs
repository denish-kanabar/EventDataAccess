﻿
/// <summary>
/// Model for incoming request from UI to Processor API
/// </summary>
namespace EventDataAccess.Models
{
    public class RequestInput
    {       
        public int BatchCount { get; init; }
        public int NumberCount { get; init; }
        public int OperationId { get; init; }
    }
}
