﻿using System.Collections.Generic;

namespace EventDataAccess.Models
{
    /// <summary>
    /// Model collection to pass request input to worker API from manager class to generate random num and multiply with random number
    /// </summary>
    public class WorkerRequest
    {
        public List<Batch> Batches { get; set; }
        public WorkType RequestWorkType { get; set; }
    }
}
