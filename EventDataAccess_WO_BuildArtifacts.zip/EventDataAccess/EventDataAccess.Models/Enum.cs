﻿namespace EventDataAccess.Models
{
    /// <summary>
    /// Enum for two type of work 
    /// </summary>
    public enum WorkType
    {
        GENERATE,
        MULTIPLY
    }
}
