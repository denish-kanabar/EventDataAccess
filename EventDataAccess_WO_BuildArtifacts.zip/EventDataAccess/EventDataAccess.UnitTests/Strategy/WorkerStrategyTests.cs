﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using EvenDataAccess.WorkerAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvenDataAccess.WorkerAPI.Tests
{
    [TestClass()]
    public class WorkerStrategyTests
    {
        [TestMethod()]
        public void WorkerStrategyTest()
        {

        }

        [TestMethod()]
        public void WorkExecutorTest()
        {

        }
    }
}