﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using EventDataAccess.Models;

namespace EvenDataAccess.WorkerAPI
{
    internal class MultiplierStrategy : IWorkTypeStrategy
    {
        /// <summary>
        /// Implements strategy for number multiplication of received batch with random delay
        /// </summary>
        /// <param name="batches">Batch detail to generate random number</param>
        /// <returns></returns>
        public IEnumerable<Batch> Execute(IList<Batch> batches)
        {
            Random random = new();
            int listCount = batches.Count;
            int iCount = 0;
            for (; iCount < listCount; iCount++)
            {
                int randomNumber = 0;
                Task task = Task.Factory.StartNew(() =>
                {
                    randomNumber = random.Next(2, 4);

                    batches[iCount].MultiplierNum= randomNumber;
                    batches[iCount].MultipliedNum = batches[iCount].GeneratedNum * randomNumber;
                    batches[iCount].MultipliedTime = DateTime.Now;

                    Task.Delay(random.Next(5, 10) * 1000).Wait();
                });
                task.Wait();
            }
            return batches;
        }
    }
}