﻿using System.Collections.Generic;
using EventDataAccess.Models;

/// <summary>
/// Implement to define strategy of specifed work type
/// </summary>
namespace EvenDataAccess.WorkerAPI
{
    interface IWorkTypeStrategy
    {
        IEnumerable<Batch> Execute(IList<Batch> batches);
    }
}
