﻿using System.Collections.Generic;
using EventDataAccess.Models;

namespace EvenDataAccess.WorkerAPI
{
    public class WorkerStrategy
    {
        private IDictionary<WorkType, IWorkTypeStrategy> WorkTypeStrategy { get; set; }

        public WorkerStrategy()
        {
            Initalizer();
        }

        /// <summary>
        /// With Object creation request defines type of strategy based on given WorkType
        /// </summary>
        private void Initalizer()
        {
            WorkTypeStrategy = new Dictionary<WorkType, IWorkTypeStrategy>
            {
                { WorkType.GENERATE, new GeneratorStrategy()},
                { WorkType.MULTIPLY, new MultiplierStrategy()}
            };

        }

        /// <summary>
        /// Reads operation type and calls method of appropriate worker
        /// </summary>
        /// <param name="batches">Income batch from Processor</param>
        /// <param name="operation">Enum based value for Generate or Multiply</param>
        /// <returns></returns>
        public IEnumerable<Batch> WorkExecutor(IList<Batch> batches, WorkType operation) 
        {
            return WorkTypeStrategy[operation].Execute(batches);
        }

    }

}