﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using EventDataAccess.Models;

namespace EvenDataAccess.WorkerAPI
{
    internal class GeneratorStrategy : IWorkTypeStrategy
    {
        /// <summary>
        /// Implements strategy for number generation of received batch with random delay
        /// </summary>
        /// <param name="batches">Batch detail to generate random number</param>
        /// <returns></returns>
        public IEnumerable<Batch> Execute(IList<Batch> batches)
        {
            Random random = new(); 
            int listCount = batches.Count;
            int iCount = 0;
            for (; iCount < listCount; iCount++)
            {
                var insideVal = iCount;
                Task task = Task.Factory.StartNew(() =>
                     {
                         batches[insideVal].GeneratedNum = random.Next(1, 100);
                         batches[insideVal].GeneratedTime= DateTime.Now;

                         Task.Delay(random.Next(5, 10) * 1000).Wait();
                     });
                task.Wait();
            }
            return batches;
        }
    }
}